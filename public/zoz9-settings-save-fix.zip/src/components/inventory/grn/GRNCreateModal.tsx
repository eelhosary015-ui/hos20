import React, { useState, useEffect, useMemo } from "react";
import {
  Truck, Plus, Trash2, ShieldCheck, AlertCircle, FileText,
  DollarSign, Package, Calendar, Hash, Tag, Layers, X,
  CheckCircle2, Sparkles, ArrowRight, ArrowLeft, Paperclip,
  Barcode, Search, Calculator, Check, AlertTriangle, Lock,
  ChevronDown, RefreshCw, Info, CheckCircle, Clock
} from "lucide-react";

interface GRNCreateModalProps {
  warehouses: any[];
  ingredients: any[];
  suppliers: any[];
  onClose: () => void;
  onSuccess: () => void;
  onNotify: (msg: string, type: "success" | "error" | "info") => void;
}

export const GRNCreateModal: React.FC<GRNCreateModalProps> = ({
  warehouses,
  ingredients,
  suppliers,
  onClose,
  onSuccess,
  onNotify
}) => {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [submitting, setSubmitting] = useState(false);
  const [purchaseOrders, setPurchaseOrders] = useState<any[]>([]);
  const [loadingPo, setLoadingPo] = useState(false);
  const [warehouseLocations, setWarehouseLocations] = useState<any[]>([]);
  const [poSearchTerm, setPoSearchTerm] = useState("");
  const [isPoDropdownOpen, setIsPoDropdownOpen] = useState(false);

  // Barcode scanner quick add
  const [scannedBarcode, setScannedBarcode] = useState("");

  // Invoice uniqueness check state
  const [invoiceChecking, setInvoiceChecking] = useState(false);
  const [invoiceStatus, setInvoiceStatus] = useState<{
    checked: boolean;
    isUnique: boolean;
    existingGrn?: string;
  }>({ checked: false, isUnique: true });

  const todayStr = new Date().toISOString().split("T")[0];

  // Form State
  const [header, setHeader] = useState({
    receipt_type: "po", // Default to 'po' (From Purchase Order) as requested
    purchase_order_id: "",
    warehouse_id: warehouses[0]?.id || "",
    supplier_id: suppliers[0]?.id || "",
    supplier_invoice_no: "",
    delivery_note_no: "",
    date: todayStr,
    posting_date: todayStr,
    receiver_name: localStorage.getItem("userName") || "مدير الاستلام",
    reference: `GRN-REF-${todayStr.replace(/-/g, "")}-${Math.floor(1000 + Math.random() * 9000)}`,
    currency: "EGP",
    exchange_rate: 1.0,
    // Landed Costs
    freight_charges: 0,
    customs_charges: 0,
    other_charges: 0,
    landed_cost_allocation: "value", // 'value', 'quantity', 'weight', 'equal'
    notes: "",
    auto_post: false,
    needs_qc: false // Send to QC Quarantine
  });

  const [items, setItems] = useState<any[]>([
    {
      ingredient_id: ingredients[0]?.id || "",
      po_item_id: null,
      ordered_qty: 0,
      previously_received_qty: 0,
      expected_qty: 10,
      received_qty: 10,
      rejected_qty: 0,
      rejection_reason: "",
      free_qty: 0,
      unit_price: Number(ingredients[0]?.cost || 0),
      discount_rate: 0,
      tax_rate: 14,
      batch_number: `BAT-${todayStr.slice(2).replace(/-/g, "")}-${Math.floor(100 + Math.random() * 900)}`,
      lot_number: "",
      expiry_date: "",
      manufacturing_date: todayStr,
      supplier_batch: "",
      serial_numbers: "",
      location_id: "",
      notes: ""
    }
  ]);

  const [attachments, setAttachments] = useState<any[]>([]);
  const [newAttachmentName, setNewAttachmentName] = useState("");
  const [newAttachmentUrl, setNewAttachmentUrl] = useState("");
  const [newAttachmentType, setNewAttachmentType] = useState("invoice");

  // Fetch approved Purchase Orders on mount
  useEffect(() => {
    const fetchPOs = async () => {
      setLoadingPo(true);
      try {
        const res = await fetch("/api/purchase-orders?status=approved&remaining_qty=true");
        let data = await res.json();
        if (Array.isArray(data)) {
          setPurchaseOrders(data);
        } else {
          // Fallback to general pending PO endpoint
          const fallbackRes = await fetch("/api/goods-receipts-po/pending");
          const fallbackData = await fallbackRes.json();
          if (fallbackData.purchase_orders) {
            setPurchaseOrders(fallbackData.purchase_orders);
          }
        }
      } catch (err) {
        console.error("Failed to load POs:", err);
      } finally {
        setLoadingPo(false);
      }
    };
    fetchPOs();
  }, []);

  // Fetch Warehouse Locations for the selected warehouse
  useEffect(() => {
    if (!header.warehouse_id) return;
    const fetchLocations = async () => {
      try {
        const res = await fetch(`/api/warehouse-locations?warehouse_id=${header.warehouse_id}`);
        const data = await res.json();
        if (data.success) {
          setWarehouseLocations(data.locations || []);
        }
      } catch (err) {
        console.error("Failed to load locations:", err);
      }
    };
    fetchLocations();
  }, [header.warehouse_id]);

  // Check Invoice Uniqueness per Supplier
  useEffect(() => {
    if (!header.supplier_id || !header.supplier_invoice_no.trim()) {
      setInvoiceStatus({ checked: false, isUnique: true });
      return;
    }

    const timer = setTimeout(async () => {
      setInvoiceChecking(true);
      try {
        const res = await fetch(
          `/api/grn/check-invoice-unique?supplier_id=${header.supplier_id}&invoice_no=${encodeURIComponent(header.supplier_invoice_no.trim())}`
        );
        const data = await res.json();
        if (data.success) {
          setInvoiceStatus({
            checked: true,
            isUnique: data.is_unique,
            existingGrn: data.existing_grn
          });
        }
      } catch (err) {
        console.error("Invoice check error:", err);
      } finally {
        setInvoiceChecking(false);
      }
    }, 400);

    return () => clearTimeout(timer);
  }, [header.supplier_id, header.supplier_invoice_no]);

  // Handle PO selection and auto-populate items & header
  const handleSelectPo = async (po: any) => {
    if (!po) {
      setHeader(prev => ({ ...prev, purchase_order_id: "" }));
      setIsPoDropdownOpen(false);
      return;
    }
    setLoadingPo(true);
    setIsPoDropdownOpen(false);
    try {
      // 1. Try fetching detailed PO items
      const res = await fetch(`/api/goods-receipts-po/${po.id}/items`);
      let poData = await res.json();

      let poItemsList: any[] = [];
      let supplierId = po.supplier_id || (header.supplier_id);
      let targetWarehouseId = header.warehouse_id;

      if (poData.success && Array.isArray(poData.items) && poData.items.length > 0) {
        poItemsList = poData.items;
        if (poData.purchase_order) {
          supplierId = poData.purchase_order.supplier_id || supplierId;
          if (poData.purchase_order.warehouse_id) {
            targetWarehouseId = poData.purchase_order.warehouse_id;
          }
        }
      } else {
        // Fallback to standard PO endpoint
        const poStandardRes = await fetch(`/api/purchase-orders/${po.id}`);
        const standardData = await poStandardRes.json();
        if (standardData && Array.isArray(standardData.items)) {
          poItemsList = standardData.items;
          supplierId = standardData.supplier_id || supplierId;
          if (standardData.warehouse_id) {
            targetWarehouseId = standardData.warehouse_id;
          }
        }
      }

      setHeader(prev => ({
        ...prev,
        purchase_order_id: String(po.id),
        supplier_id: supplierId || prev.supplier_id,
        warehouse_id: targetWarehouseId || prev.warehouse_id,
        reference: `أمر شراء #${po.id}`
      }));

      if (poItemsList.length > 0) {
        const mappedItems = poItemsList.map((pi: any) => {
          const ordered = Number(pi.quantity || pi.ordered_qty || 0);
          const alreadyReceived = Number(pi.received_quantity || pi.previously_received_qty || 0);
          const remaining = Math.max(0, ordered - alreadyReceived);
          const defaultRecv = remaining > 0 ? remaining : ordered;

          return {
            ingredient_id: pi.ingredient_id,
            po_item_id: pi.id || pi.po_item_id || null,
            ordered_qty: ordered,
            previously_received_qty: alreadyReceived,
            expected_qty: remaining,
            received_qty: defaultRecv,
            rejected_qty: 0,
            rejection_reason: "",
            free_qty: 0,
            unit_price: Number(pi.unit_price || 0),
            discount_rate: 0,
            tax_rate: 14,
            batch_number: `BAT-${todayStr.slice(2).replace(/-/g, "")}-${Math.floor(100 + Math.random() * 900)}`,
            lot_number: "",
            expiry_date: "",
            manufacturing_date: todayStr,
            supplier_batch: "",
            serial_numbers: "",
            location_id: "",
            notes: ""
          };
        });

        setItems(mappedItems);
        onNotify(`تم استيراد ${mappedItems.length} صنف من أمر الشراء #${po.id} بنجاح`, "success");
      } else {
        onNotify(`تم ربط أمر الشراء #${po.id}`, "info");
      }
    } catch (err) {
      console.error("Failed to load PO details:", err);
      onNotify("فشل جلب تفاصيل أمر الشراء المحدد", "error");
    } finally {
      setLoadingPo(false);
    }
  };

  // Auto-generate reference code
  const handleRegenerateReference = () => {
    const newRef = `GRN-REF-${todayStr.replace(/-/g, "")}-${Math.floor(1000 + Math.random() * 9000)}`;
    setHeader(prev => ({ ...prev, reference: newRef }));
  };

  // Add Item Row
  const handleAddItem = () => {
    const firstIng = ingredients[0];
    setItems(prev => [
      ...prev,
      {
        ingredient_id: firstIng?.id || "",
        po_item_id: null,
        ordered_qty: 0,
        previously_received_qty: 0,
        expected_qty: 1,
        received_qty: 1,
        rejected_qty: 0,
        rejection_reason: "",
        free_qty: 0,
        unit_price: Number(firstIng?.cost || 0),
        discount_rate: 0,
        tax_rate: 14,
        batch_number: `BAT-${todayStr.slice(2).replace(/-/g, "")}-${Math.floor(100 + Math.random() * 900)}`,
        lot_number: "",
        expiry_date: "",
        manufacturing_date: todayStr,
        supplier_batch: "",
        serial_numbers: "",
        location_id: "",
        notes: ""
      }
    ]);
  };

  const handleRemoveItem = (index: number) => {
    if (items.length <= 1) {
      onNotify("يجب أن يحتوي سند الاستلام على صنف واحد على الأقل", "error");
      return;
    }
    setItems(prev => prev.filter((_, i) => i !== index));
  };

  const handleItemChange = (index: number, field: string, value: any) => {
    setItems(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      if (field === "ingredient_id") {
        const found = ingredients.find(ing => ing.id === Number(value));
        if (found) {
          updated[index].unit_price = Number(found.cost || 0);
        }
      }
      return updated;
    });
  };

  // Quick scan barcode handler
  const handleScanBarcode = () => {
    if (!scannedBarcode.trim()) return;
    const searchVal = scannedBarcode.trim().toLowerCase();
    const match = ingredients.find(ing =>
      (ing.barcode && ing.barcode.toLowerCase() === searchVal) ||
      (ing.item_code && ing.item_code.toLowerCase() === searchVal) ||
      (ing.sku && ing.sku.toLowerCase() === searchVal)
    );

    if (match) {
      const existingIdx = items.findIndex(it => it.ingredient_id === match.id);
      if (existingIdx >= 0) {
        handleItemChange(existingIdx, "received_qty", Number(items[existingIdx].received_qty || 0) + 1);
        onNotify(`تمت زيادة كمية الصنف: ${match.name}`, "success");
      } else {
        setItems(prev => [
          ...prev,
          {
            ingredient_id: match.id,
            po_item_id: null,
            ordered_qty: 0,
            previously_received_qty: 0,
            expected_qty: 1,
            received_qty: 1,
            rejected_qty: 0,
            rejection_reason: "",
            free_qty: 0,
            unit_price: Number(match.cost || 0),
            discount_rate: 0,
            tax_rate: 14,
            batch_number: `BAT-${todayStr.slice(2).replace(/-/g, "")}-${Math.floor(100 + Math.random() * 900)}`,
            lot_number: "",
            expiry_date: "",
            manufacturing_date: todayStr,
            supplier_batch: "",
            serial_numbers: "",
            location_id: "",
            notes: ""
          }
        ]);
        onNotify(`تمت إضافة الصنف بالمسح: ${match.name}`, "success");
      }
      setScannedBarcode("");
    } else {
      onNotify("لم يتم العثور على صنف مطابق لهذا الباركود أو الكود", "error");
    }
  };

  // Add Attachment
  const handleAddAttachment = () => {
    if (!newAttachmentName.trim() || !newAttachmentUrl.trim()) {
      onNotify("يرجى إدخال اسم المستند ورابط أو مسار الملف", "error");
      return;
    }
    setAttachments(prev => [
      ...prev,
      {
        file_name: newAttachmentName.trim(),
        file_url: newAttachmentUrl.trim(),
        doc_type: newAttachmentType
      }
    ]);
    setNewAttachmentName("");
    setNewAttachmentUrl("");
  };

  const handleRemoveAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  // Real-time Landed Cost & Total Calculations
  const calculations = useMemo(() => {
    let subtotal = 0;
    let totalDiscount = 0;
    let totalTax = 0;
    let totalQty = 0;
    let totalWeight = 0;

    items.forEach(it => {
      const qty = Number(it.received_qty || 0);
      const price = Number(it.unit_price || 0);
      const disc = Number(it.discount_rate || 0);
      const tax = Number(it.tax_rate || 0);
      const ing = ingredients.find(i => i.id === Number(it.ingredient_id));
      const unitWeight = Number(ing?.weight || 1);

      const gross = qty * price;
      const discVal = gross * (disc / 100);
      const taxable = gross - discVal;
      const taxVal = taxable * (tax / 100);

      subtotal += gross;
      totalDiscount += discVal;
      totalTax += taxVal;
      totalQty += qty;
      totalWeight += qty * unitWeight;
    });

    const netAmount = subtotal - totalDiscount + totalTax;
    const extraLandedCosts =
      Number(header.freight_charges || 0) +
      Number(header.customs_charges || 0) +
      Number(header.other_charges || 0);
    const totalLandedCost = netAmount + extraLandedCosts;

    // Per item landed cost breakdown
    const itemLandedList = items.map(it => {
      const qty = Number(it.received_qty || 0);
      const price = Number(it.unit_price || 0);
      const disc = Number(it.discount_rate || 0);
      const tax = Number(it.tax_rate || 0);
      const ing = ingredients.find(i => i.id === Number(it.ingredient_id));
      const unitWeight = Number(ing?.weight || 1);

      const gross = qty * price;
      const discVal = gross * (disc / 100);
      const lineNet = gross - discVal + ((gross - discVal) * (tax / 100));

      let allocatedExtra = 0;
      if (extraLandedCosts > 0 && items.length > 0) {
        if (header.landed_cost_allocation === "quantity" && totalQty > 0) {
          allocatedExtra = (qty / totalQty) * extraLandedCosts;
        } else if (header.landed_cost_allocation === "weight" && totalWeight > 0) {
          allocatedExtra = ((qty * unitWeight) / totalWeight) * extraLandedCosts;
        } else if (header.landed_cost_allocation === "equal") {
          allocatedExtra = extraLandedCosts / items.length;
        } else {
          // Default: by value
          allocatedExtra = netAmount > 0 ? (lineNet / netAmount) * extraLandedCosts : 0;
        }
      }

      const totalItemLanded = lineNet + allocatedExtra;
      const unitLanded = qty > 0 ? totalItemLanded / qty : price;
      const extraPerUnit = qty > 0 ? allocatedExtra / qty : 0;

      return {
        lineNet,
        allocatedExtra,
        totalItemLanded,
        unitLanded,
        extraPerUnit
      };
    });

    return {
      subtotal,
      totalDiscount,
      totalTax,
      totalQty,
      netAmount,
      extraLandedCosts,
      totalLandedCost,
      itemLandedList
    };
  }, [items, header.freight_charges, header.customs_charges, header.other_charges, header.landed_cost_allocation, ingredients]);

  // Filtered PO list for search
  const filteredPurchaseOrders = useMemo(() => {
    if (!poSearchTerm.trim()) return purchaseOrders;
    const term = poSearchTerm.trim().toLowerCase();
    return purchaseOrders.filter(po =>
      String(po.id).includes(term) ||
      (po.supplier_name && po.supplier_name.toLowerCase().includes(term)) ||
      (po.po_number && po.po_number.toLowerCase().includes(term))
    );
  }, [purchaseOrders, poSearchTerm]);

  const selectedPo = useMemo(() => {
    return purchaseOrders.find(po => String(po.id) === String(header.purchase_order_id));
  }, [purchaseOrders, header.purchase_order_id]);

  // Selected supplier details
  const selectedSupplierObj = useMemo(() => {
    return suppliers.find(s => String(s.id) === String(header.supplier_id));
  }, [suppliers, header.supplier_id]);

  // Three-Way Matching Comparison
  const threeWayMatch = useMemo(() => {
    const poTotal = selectedPo ? Number(selectedPo.total_amount || 0) : 0;
    const receivedNet = calculations.netAmount;
    const diff = Math.abs(poTotal - receivedNet);
    const isMatching = poTotal > 0 && diff < 1;

    return {
      poTotal,
      receivedNet,
      diff,
      isMatching,
      hasPo: Boolean(selectedPo)
    };
  }, [selectedPo, calculations.netAmount]);

  // Submit Handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!header.warehouse_id) {
      onNotify("يرجى تحديد المخزن المستلم", "error");
      setStep(1);
      return;
    }
    if (header.receipt_type === "po" && !header.purchase_order_id) {
      onNotify("يرجى اختيار أمر الشراء المطلوب استلامه", "error");
      setStep(1);
      return;
    }
    if (items.length === 0) {
      onNotify("يرجى إضافة صنف واحد على الأقل", "error");
      setStep(2);
      return;
    }

    // Validate quantities & batch numbers
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      if (Number(it.received_qty) <= 0) {
        onNotify(`الصنف رقم ${i + 1}: الكمية المستلمة يجب أن تكون أكبر من صفر`, "error");
        setStep(2);
        return;
      }
      if (!it.batch_number || !it.batch_number.trim()) {
        onNotify(`الصنف رقم ${i + 1}: رقم التشغيلة (Batch #) إجباري لتتبع المخزون`, "error");
        setStep(2);
        return;
      }
    }

    setSubmitting(true);
    try {
      const payload = {
        warehouse_id: Number(header.warehouse_id),
        supplier_id: header.supplier_id ? Number(header.supplier_id) : null,
        purchase_order_id: header.purchase_order_id ? Number(header.purchase_order_id) : null,
        supplier_invoice_no: header.supplier_invoice_no.trim() || null,
        delivery_note_no: header.delivery_note_no.trim() || null,
        date: header.date,
        posting_date: header.posting_date,
        currency: header.currency,
        exchange_rate: Number(header.exchange_rate || 1),
        receiver_name: header.receiver_name,
        reference: header.reference,
        freight_charges: Number(header.freight_charges || 0),
        customs_charges: Number(header.customs_charges || 0),
        other_charges: Number(header.other_charges || 0),
        landed_cost_allocation: header.landed_cost_allocation,
        notes: header.notes,
        auto_post: header.auto_post,
        qc_status: header.needs_qc ? "pending" : (header.auto_post ? "passed" : "pending"),
        status: header.auto_post ? "posted" : "draft",
        attachments,
        items: items.map((it, idx) => ({
          ...it,
          landed_unit_cost: calculations.itemLandedList[idx]?.unitLanded || it.unit_price,
          total_landed_cost: calculations.itemLandedList[idx]?.totalItemLanded || (Number(it.received_qty) * Number(it.unit_price)),
          accepted_qty: header.auto_post ? Number(it.received_qty) : (Number(it.received_qty) - Number(it.rejected_qty || 0)),
          quarantine_qty: header.needs_qc ? Number(it.received_qty) : 0
        }))
      };

      const res = await fetch("/api/goods-receipts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();

      if (data.success) {
        onNotify(data.message || "تم إنشاء سند الاستلام بنجاح", "success");
        onSuccess();
        onClose();
      } else {
        onNotify(data.error || "فشل تسجيل سند الاستلام", "error");
      }
    } catch (err: any) {
      console.error("Submit GRN error:", err);
      onNotify("حدث خطأ أثناء حفظ سند الاستلام", "error");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto" dir="rtl">
      <div className="bg-white rounded-3xl max-w-5xl w-full shadow-2xl border border-slate-100 overflow-hidden my-auto flex flex-col max-h-[92vh]">
        
        {/* Wizard Header */}
        <div className="p-5 bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-2xl border border-emerald-500/30">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-tight">معالج تسجيل سند استلام وارد وفحص جودة (GRN)</h2>
              <p className="text-xs text-slate-300">استلام بضاعة، مطابقة أوامر الشراء، تسجيل أرقام التشغيلات، وحساب التكاليف الإضافية</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wizard Stepper Bar */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-3 flex items-center justify-between text-xs font-bold">
          <div className="flex items-center gap-6 sm:gap-8">
            <button
              type="button"
              onClick={() => setStep(1)}
              className={`flex items-center gap-2 pb-1 border-b-2 transition-all ${
                step === 1 ? "border-emerald-600 text-emerald-700 font-black" : "border-transparent text-slate-500 hover:text-slate-700"
              }`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step === 1 ? "bg-emerald-600 text-white" : "bg-slate-200 text-slate-700"
              }`}>1</span>
              بيانات الاستلام والمورد والتكاليف
            </button>

            <button
              type="button"
              onClick={() => setStep(2)}
              className={`flex items-center gap-2 pb-1 border-b-2 transition-all ${
                step === 2 ? "border-emerald-600 text-emerald-700 font-black" : "border-transparent text-slate-500 hover:text-slate-700"
              }`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step === 2 ? "bg-emerald-600 text-white" : "bg-slate-200 text-slate-700"
              }`}>2</span>
              الأصناف والكميات ({items.length})
            </button>

            <button
              type="button"
              onClick={() => setStep(3)}
              className={`flex items-center gap-2 pb-1 border-b-2 transition-all ${
                step === 3 ? "border-emerald-600 text-emerald-700 font-black" : "border-transparent text-slate-500 hover:text-slate-700"
              }`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step === 3 ? "bg-emerald-600 text-white" : "bg-slate-200 text-slate-700"
              }`}>3</span>
              المرفقات والمراجعة
            </button>
          </div>

          <div className="text-emerald-800 bg-emerald-100/90 px-3 py-1 rounded-xl font-mono font-bold text-xs shadow-sm border border-emerald-200">
            الإجمالي المحمل: {calculations.totalLandedCost.toLocaleString()} ج.م
          </div>
        </div>

        {/* Wizard Form Content */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* STEP 1: RECEIPT SOURCE, PO, SUPPLIER & LANDED COSTS */}
          {step === 1 && (
            <div className="space-y-5">
              {/* Row 1 - Inbound Source Radio Options */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2.5">
                <label className="block text-xs font-black text-slate-800">مصدر سند الاستلام (Inbound Source)</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <label className={`flex items-center gap-3 p-3.5 rounded-2xl border cursor-pointer transition-all ${
                    header.receipt_type === "po"
                      ? "bg-white border-emerald-500 shadow-sm ring-2 ring-emerald-500/20"
                      : "bg-slate-100/60 border-slate-200 hover:bg-white"
                  }`}>
                    <input
                      type="radio"
                      name="receipt_type"
                      checked={header.receipt_type === "po"}
                      onChange={() => setHeader({ ...header, receipt_type: "po" })}
                      className="text-emerald-600 w-4 h-4"
                    />
                    <div>
                      <span className="font-bold text-xs text-slate-900 block">استلام بناءً على أمر شراء (From Purchase Order)</span>
                      <span className="text-[11px] text-slate-500 block">مطابقة الكميات المتبقية وتحديث حالة أمر الشراء تلقائياً</span>
                    </div>
                  </label>

                  <label className={`flex items-center gap-3 p-3.5 rounded-2xl border cursor-pointer transition-all ${
                    header.receipt_type === "direct"
                      ? "bg-white border-emerald-500 shadow-sm ring-2 ring-emerald-500/20"
                      : "bg-slate-100/60 border-slate-200 hover:bg-white"
                  }`}>
                    <input
                      type="radio"
                      name="receipt_type"
                      checked={header.receipt_type === "direct"}
                      onChange={() => setHeader({ ...header, receipt_type: "direct", purchase_order_id: "" })}
                      className="text-emerald-600 w-4 h-4"
                    />
                    <div>
                      <span className="font-bold text-xs text-slate-900 block">استلام مباشر (Direct Receipt)</span>
                      <span className="text-[11px] text-slate-500 block">توريد بدون أمر شراء مسبق أو استلام بضاعة نقدية فورية</span>
                    </div>
                  </label>
                </div>
              </div>

              {/* Row 2 - Searchable Select2 Style PO Selector (if PO selected) */}
              {header.receipt_type === "po" && (
                <div className="bg-emerald-50/40 p-4 rounded-2xl border border-emerald-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-black text-emerald-950 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                      اختر أمر الشراء المعتمد * (Select Purchase Order)
                    </label>
                    <span className="text-[11px] text-emerald-700 font-bold">
                      {loadingPo ? "جاري تحميل أوامر الشراء..." : `${purchaseOrders.length} أوامر شراء جاهزة للاستلام`}
                    </span>
                  </div>

                  {/* Searchable Select Dropdown Container */}
                  <div className="relative">
                    <div
                      onClick={() => setIsPoDropdownOpen(!isPoDropdownOpen)}
                      className="w-full px-3.5 py-2.5 bg-white border border-emerald-300 rounded-xl text-xs font-bold text-slate-800 flex items-center justify-between cursor-pointer shadow-sm hover:border-emerald-500 transition-all"
                    >
                      {selectedPo ? (
                        <div className="flex items-center gap-2 overflow-hidden">
                          <span className="bg-emerald-600 text-white px-2 py-0.5 rounded font-mono text-[11px]">
                            PO #{selectedPo.id}
                          </span>
                          <span className="font-bold text-slate-900 truncate">
                            المورد: {selectedPo.supplier_name || "مورد"}
                          </span>
                          <span className="text-slate-500 text-[11px]">
                            ({Number(selectedPo.total_amount || 0).toLocaleString()} ج.م)
                          </span>
                          <span className="bg-emerald-100 text-emerald-800 text-[10px] px-2 py-0.5 rounded-full font-bold">
                            {selectedPo.status === "approved" ? "معتمد" : "استلام جزئي"}
                          </span>
                          {selectedPo.remaining_items_count !== undefined && (
                            <span className="bg-blue-50 text-blue-700 border border-blue-200 text-[10px] px-2 py-0.5 rounded font-bold">
                              {selectedPo.remaining_items_count} أصناف متبقية
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="text-slate-400">
                          -- اضغط للبحث واختيار أمر شراء لتحميل الأصناف تلقائياً --
                        </span>
                      )}
                      <ChevronDown className={`w-4 h-4 text-slate-500 transition-transform ${isPoDropdownOpen ? "rotate-180" : ""}`} />
                    </div>

                    {/* PO Dropdown Menu */}
                    {isPoDropdownOpen && (
                      <div className="absolute top-full right-0 left-0 mt-1 bg-white rounded-2xl shadow-xl border border-slate-200 z-30 p-2 space-y-2 max-h-64 overflow-y-auto">
                        <div className="relative">
                          <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-2.5" />
                          <input
                            type="text"
                            placeholder="ابحث برقم أمر الشراء أو اسم المورد..."
                            value={poSearchTerm}
                            onChange={(e) => setPoSearchTerm(e.target.value)}
                            onClick={(e) => e.stopPropagation()}
                            className="w-full pl-3 pr-8 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                            autoFocus
                          />
                        </div>

                        <div className="space-y-1">
                          {filteredPurchaseOrders.length === 0 ? (
                            <div className="p-3 text-center text-xs text-slate-500">
                              لا توجد أوامر شراء مطابقة للبحث أو معتمدة
                            </div>
                          ) : (
                            filteredPurchaseOrders.map(po => (
                              <button
                                key={po.id}
                                type="button"
                                onClick={() => handleSelectPo(po)}
                                className={`w-full p-2.5 rounded-xl text-right flex items-center justify-between text-xs transition-all hover:bg-emerald-50 ${
                                  String(header.purchase_order_id) === String(po.id) ? "bg-emerald-100/70 border border-emerald-300" : ""
                                }`}
                              >
                                <div className="space-y-0.5">
                                  <div className="flex items-center gap-2">
                                    <span className="font-mono font-bold text-emerald-700">أمر شراء #{po.id}</span>
                                    <span className="font-bold text-slate-800">{po.supplier_name || "مورد"}</span>
                                  </div>
                                  <div className="text-[11px] text-slate-500 flex items-center gap-2">
                                    <span>المبلغ: {Number(po.total_amount || 0).toLocaleString()} ج.م</span>
                                    <span>•</span>
                                    <span>التاريخ: {po.date ? new Date(po.date).toLocaleDateString("ar-EG") : "-"}</span>
                                  </div>
                                </div>

                                <div className="flex items-center gap-1.5">
                                  <span className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-bold">
                                    {po.status === "approved" ? "معتمد" : "استلام جزئي"}
                                  </span>
                                  {po.remaining_items_count !== undefined && (
                                    <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-bold">
                                      {po.remaining_items_count} أصناف متبقية
                                    </span>
                                  )}
                                </div>
                              </button>
                            ))
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Row 3 - 3 Fields: Warehouse, Supplier, Receiver Name */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* 1. Receiving Warehouse */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">المخزن المستلم *</label>
                    {header.receipt_type === "po" && selectedPo && (
                      <span className="text-[10px] text-emerald-700 font-bold">
                        مخزن أمر الشراء
                      </span>
                    )}
                  </div>
                  <select
                    value={header.warehouse_id}
                    onChange={(e) => setHeader({ ...header, warehouse_id: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-none focus:ring-2 focus:ring-emerald-500"
                    required
                  >
                    {warehouses.map(w => (
                      <option key={w.id} value={w.id}>{w.name} ({w.code || w.id})</option>
                    ))}
                  </select>
                </div>

                {/* 2. Supplier (Locked if PO, Free Select if Direct) */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">المورد *</label>
                    {header.receipt_type === "po" && (
                      <span className="text-[10px] text-slate-400 flex items-center gap-1">
                        <Lock className="w-2.5 h-2.5" /> مقفل بأمر الشراء
                      </span>
                    )}
                  </div>
                  {header.receipt_type === "po" ? (
                    <div className="w-full px-3 py-2 bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 flex items-center justify-between">
                      <span className="truncate">
                        {selectedSupplierObj ? `${selectedSupplierObj.name} (${selectedSupplierObj.tax_number || selectedSupplierObj.phone || "مورد"})` : (selectedPo?.supplier_name || "مورد أمر الشراء")}
                      </span>
                      <Lock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    </div>
                  ) : (
                    <select
                      value={header.supplier_id}
                      onChange={(e) => setHeader({ ...header, supplier_id: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="">-- مورد عام / نقدي --</option>
                      {suppliers.map(s => (
                        <option key={s.id} value={s.id}>{s.name} ({s.tax_number || s.phone || "مورد"})</option>
                      ))}
                    </select>
                  )}
                </div>

                {/* 3. Receiver Name */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">اسم المستلم / أمين المخزن</label>
                  <input
                    type="text"
                    value={header.receiver_name}
                    onChange={(e) => setHeader({ ...header, receiver_name: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="اسم أمين المخزن المسؤول"
                  />
                </div>
              </div>

              {/* Row 4 - 3 Fields: Supplier Invoice # (with unique check), Delivery Note, Reference */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* 4. Supplier Invoice # with Uniqueness Checker */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">رقم فاتورة المورد</label>
                    {invoiceChecking && (
                      <span className="text-[10px] text-slate-400 animate-pulse">جاري التحقق...</span>
                    )}
                  </div>
                  <div className="relative">
                    <input
                      type="text"
                      value={header.supplier_invoice_no}
                      onChange={(e) => setHeader({ ...header, supplier_invoice_no: e.target.value })}
                      className={`w-full pl-8 pr-3 py-2 bg-slate-50 border rounded-xl text-xs font-mono font-bold outline-none transition-all ${
                        invoiceStatus.checked && !invoiceStatus.isUnique
                          ? "border-rose-400 ring-2 ring-rose-200 bg-rose-50/50"
                          : invoiceStatus.checked && invoiceStatus.isUnique && header.supplier_invoice_no
                          ? "border-emerald-400 ring-2 ring-emerald-200"
                          : "border-slate-200 focus:ring-2 focus:ring-emerald-500"
                      }`}
                      placeholder="مثال: INV-2026-8941"
                    />
                    <div className="absolute left-2.5 top-2.5">
                      {header.supplier_invoice_no && invoiceStatus.checked && (
                        invoiceStatus.isUnique ? (
                          <CheckCircle className="w-4 h-4 text-emerald-600" />
                        ) : (
                          <AlertTriangle className="w-4 h-4 text-rose-600" />
                        )
                      )}
                    </div>
                  </div>
                  {invoiceStatus.checked && !invoiceStatus.isUnique && (
                    <span className="text-[10px] text-rose-600 font-bold block mt-1">
                      ⚠️ هذا الرقم مسجل مسبقاً في سند الاستلام {invoiceStatus.existingGrn}
                    </span>
                  )}
                </div>

                {/* 5. Delivery Note # */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">رقم إذن التسليم / البوليصة (Delivery Note)</label>
                  <input
                    type="text"
                    value={header.delivery_note_no}
                    onChange={(e) => setHeader({ ...header, delivery_note_no: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="مثال: DN-99410"
                  />
                </div>

                {/* 6. Reference / Shipment Code with Regenerate Button */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">المرجع / كود الشحنة</label>
                    <button
                      type="button"
                      onClick={handleRegenerateReference}
                      className="text-[10px] text-emerald-600 hover:text-emerald-700 flex items-center gap-1 font-bold"
                    >
                      <RefreshCw className="w-2.5 h-2.5" /> توليد جديد
                    </button>
                  </div>
                  <input
                    type="text"
                    value={header.reference}
                    onChange={(e) => setHeader({ ...header, reference: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="كود مرجعي فريد للشحنة"
                  />
                </div>
              </div>

              {/* Row 5 - 3 Fields: Dates & Currency */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* 7. Actual Receipt Date (Max today) */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">تاريخ الاستلام الفعلي *</label>
                  <input
                    type="date"
                    max={todayStr}
                    value={header.date}
                    onChange={(e) => setHeader({ ...header, date: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold outline-none focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>

                {/* 8. Posting Date with Open Period Info */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">تاريخ الترحيل المحاسبي *</label>
                    <span className="text-[10px] text-emerald-700 font-bold flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> الفترة مفتوحة
                    </span>
                  </div>
                  <input
                    type="date"
                    value={header.posting_date}
                    onChange={(e) => setHeader({ ...header, posting_date: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold outline-none focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>

                {/* 9. Currency & Exchange Rate */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">العملة وسعر الصرف</label>
                  <div className="grid grid-cols-2 gap-2">
                    <select
                      value={header.currency}
                      onChange={(e) => {
                        const newCurr = e.target.value;
                        setHeader({
                          ...header,
                          currency: newCurr,
                          exchange_rate: newCurr === "EGP" ? 1.0 : (header.exchange_rate === 1.0 ? 50.5 : header.exchange_rate)
                        });
                      }}
                      className="px-2 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                    >
                      <option value="EGP">EGP (ج.م)</option>
                      <option value="USD">USD ($)</option>
                      <option value="EUR">EUR (€)</option>
                      <option value="SAR">SAR (ر.س)</option>
                      <option value="AED">AED (د.إ)</option>
                    </select>
                    <input
                      type="number"
                      step="0.001"
                      min="0.001"
                      disabled={header.currency === "EGP"}
                      value={header.exchange_rate}
                      onChange={(e) => setHeader({ ...header, exchange_rate: parseFloat(e.target.value) || 1 })}
                      className={`px-2 py-2 border rounded-xl text-xs font-mono text-center font-bold ${
                        header.currency === "EGP" ? "bg-slate-100 border-slate-200 text-slate-500" : "bg-white border-slate-300 text-slate-900"
                      }`}
                      placeholder="سعر الصرف"
                    />
                  </div>
                </div>
              </div>

              {/* Row 6 - Landed Cost Breakdown & Allocation Card */}
              <div className="bg-emerald-50/50 p-4 rounded-2xl border border-emerald-200 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Calculator className="w-4 h-4 text-emerald-700" />
                    <h4 className="font-black text-xs text-emerald-950">التكاليف الإضافية والشحن والجمارك (Landed Costs Allocation)</h4>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
                    <span>طريقة التوزيع على الأصناف:</span>
                    <select
                      value={header.landed_cost_allocation}
                      onChange={(e) => setHeader({ ...header, landed_cost_allocation: e.target.value })}
                      className="px-2.5 py-1 bg-white border border-emerald-300 rounded-lg text-xs font-bold text-emerald-900 shadow-sm"
                    >
                      <option value="value">حسب القيمة المالية (By Item Value) - افتراضي</option>
                      <option value="quantity">حسب الكميات المستلمة (By Quantity)</option>
                      <option value="weight">حسب الوزن الإجمالي (By Weight)</option>
                      <option value="equal">بالتساوي بين الأصناف (Evenly Distributed)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">مصاريف الشحن والنقل (Freight)</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={header.freight_charges}
                      onChange={(e) => setHeader({ ...header, freight_charges: parseFloat(e.target.value) || 0 })}
                      className="w-full px-3 py-1.5 bg-white border border-emerald-200 rounded-xl text-xs font-mono font-bold text-slate-800"
                      placeholder="0.00"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">الرسوم الجمركية والضرائب الخاصة (Customs)</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={header.customs_charges}
                      onChange={(e) => setHeader({ ...header, customs_charges: parseFloat(e.target.value) || 0 })}
                      className="w-full px-3 py-1.5 bg-white border border-emerald-200 rounded-xl text-xs font-mono font-bold text-slate-800"
                      placeholder="0.00"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">مصاريف تفريغ وتخزين أخرى (Other Fees)</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={header.other_charges}
                      onChange={(e) => setHeader({ ...header, other_charges: parseFloat(e.target.value) || 0 })}
                      className="w-full px-3 py-1.5 bg-white border border-emerald-200 rounded-xl text-xs font-mono font-bold text-slate-800"
                      placeholder="0.00"
                    />
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between text-xs font-bold pt-2 border-t border-emerald-200/70 text-emerald-950">
                  <div className="flex items-center gap-2">
                    <span className="bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded-lg font-mono">
                      إجمالي المصاريف المحملة: {calculations.extraLandedCosts.toLocaleString()} ج.م
                    </span>
                  </div>
                  <span className="text-[11px] text-emerald-800">
                    سيتم توزيع {calculations.extraLandedCosts.toLocaleString()} ج.م على الأصناف لزيادة تكلفة الوحدة المخزنية (Landed Unit Cost)
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: ITEMS, QUANTITIES, BATCHES & LANDED UNIT COSTS */}
          {step === 2 && (
            <div className="space-y-4">
              {/* Top Quick Bar: Barcode Scanner & Add Item Button */}
              <div className="p-3.5 bg-slate-900 text-white rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-md">
                <div className="flex items-center gap-2 flex-1 min-w-[280px]">
                  <Barcode className="w-5 h-5 text-emerald-400 shrink-0" />
                  <input
                    type="text"
                    placeholder="امسح الباركود أو كود الصنف بالماسح الضوئي لإضافته أو زيادة الكمية..."
                    value={scannedBarcode}
                    onChange={(e) => setScannedBarcode(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); handleScanBarcode(); } }}
                    className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder:text-slate-400 outline-none focus:border-emerald-500"
                  />
                  <button
                    type="button"
                    onClick={handleScanBarcode}
                    className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-all"
                  >
                    إضافة
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleAddItem}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 rounded-xl text-xs font-bold transition-all"
                >
                  <Plus className="w-4 h-4" /> إضافة صنف جديد
                </button>
              </div>

              {/* Items List Cards */}
              <div className="space-y-4">
                {items.map((it, idx) => {
                  const selectedIngredient = ingredients.find(ing => ing.id === Number(it.ingredient_id));
                  const rQty = Number(it.received_qty || 0);
                  const ordQty = Number(it.ordered_qty || 0);
                  const remQty = Number(it.expected_qty || 0);
                  const isOverReceived = it.po_item_id && ordQty > 0 && rQty > remQty;
                  const itemLandedCalc = calculations.itemLandedList[idx] || {
                    lineNet: 0,
                    unitLanded: it.unit_price,
                    extraPerUnit: 0
                  };

                  // Expiry check (alert if < 30 days)
                  const isNearExpiry = it.expiry_date && (new Date(it.expiry_date).getTime() - new Date().getTime()) < (30 * 24 * 60 * 60 * 1000);

                  return (
                    <div
                      key={idx}
                      className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3 relative hover:border-slate-300 transition-all shadow-sm"
                    >
                      {/* Card Header: Item Name, PO Context Badges, Line Net, Delete */}
                      <div className="flex flex-wrap items-center justify-between border-b border-slate-200 pb-2.5 gap-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="w-6 h-6 rounded-full bg-emerald-600 text-white text-xs font-black flex items-center justify-center">
                            {idx + 1}
                          </span>
                          <span className="font-bold text-xs text-slate-900">
                            {selectedIngredient ? `${selectedIngredient.name} (${selectedIngredient.item_code || selectedIngredient.id})` : "صنف استلام"}
                          </span>
                          {selectedIngredient?.category && (
                            <span className="text-[10px] bg-slate-200 text-slate-700 px-2 py-0.5 rounded font-bold">
                              {selectedIngredient.category}
                            </span>
                          )}

                          {/* PO Badges if linked to PO item */}
                          {it.po_item_id && (
                            <div className="flex items-center gap-1.5 text-[10px]">
                              <span className="bg-slate-200 text-slate-700 px-2 py-0.5 rounded font-mono font-bold">
                                المطلوب: {ordQty}
                              </span>
                              <span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded font-mono font-bold">
                                المستلم سابقاً: {it.previously_received_qty || 0}
                              </span>
                              <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-mono font-bold">
                                المتبقي: {remQty}
                              </span>
                              {isOverReceived && (
                                <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-bold flex items-center gap-1">
                                  <AlertTriangle className="w-3 h-3" /> تجاوز الكمية المطلوبة
                                </span>
                              )}
                            </div>
                          )}
                        </div>

                        <div className="flex items-center gap-3">
                          <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-100/70 px-2.5 py-1 rounded-lg">
                            صافي البند: {itemLandedCalc.lineNet.toFixed(2)} ج.م
                          </span>
                          {items.length > 1 && (
                            <button
                              type="button"
                              onClick={() => handleRemoveItem(idx)}
                              className="p-1.5 text-rose-500 hover:bg-rose-100 rounded-lg transition-colors"
                              title="حذف هذا الصنف من السند"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Row 1: Item Selection & Quantities */}
                      <div className="grid grid-cols-1 sm:grid-cols-6 gap-3">
                        <div className="sm:col-span-2">
                          <label className="block text-[11px] font-bold text-slate-600 mb-1">الصنف *</label>
                          <select
                            value={it.ingredient_id}
                            disabled={Boolean(it.po_item_id)}
                            onChange={(e) => handleItemChange(idx, "ingredient_id", Number(e.target.value))}
                            className={`w-full px-2.5 py-1.5 border rounded-xl text-xs font-bold outline-none ${
                              it.po_item_id ? "bg-slate-100 border-slate-200 text-slate-700" : "bg-white border-slate-200 text-slate-800 focus:ring-2 focus:ring-emerald-500"
                            }`}
                            required
                          >
                            {ingredients.map(ing => (
                              <option key={ing.id} value={ing.id}>{ing.name} ({ing.unit || "وحدة"})</option>
                            ))}
                          </select>
                        </div>

                        {/* Received Qty */}
                        <div>
                          <label className="block text-[11px] font-bold text-slate-600 mb-1">الكمية المستلمة *</label>
                          <input
                            type="number"
                            step="any"
                            min="0.001"
                            value={it.received_qty}
                            onChange={(e) => handleItemChange(idx, "received_qty", e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 outline-none focus:ring-2 focus:ring-emerald-500"
                            required
                          />
                        </div>

                        {/* Rejected Qty */}
                        <div>
                          <label className="block text-[11px] font-bold text-slate-600 mb-1">كمية مرفوضة مبدئياً</label>
                          <input
                            type="number"
                            step="any"
                            min="0"
                            value={it.rejected_qty}
                            onChange={(e) => handleItemChange(idx, "rejected_qty", e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-mono text-rose-600 font-bold"
                            placeholder="0"
                          />
                        </div>

                        {/* Bonus / Free Qty */}
                        <div>
                          <label className="block text-[11px] font-bold text-slate-600 mb-1">بونص / عينات مجانية</label>
                          <input
                            type="number"
                            step="any"
                            min="0"
                            value={it.free_qty}
                            onChange={(e) => handleItemChange(idx, "free_qty", e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-mono text-blue-600 font-bold"
                            placeholder="0"
                          />
                        </div>

                        {/* Unit Price (Locked if PO, editable if Direct) */}
                        <div>
                          <label className="block text-[11px] font-bold text-slate-600 mb-1">سعر الشراء (ج.م) *</label>
                          <input
                            type="number"
                            step="any"
                            min="0"
                            disabled={Boolean(it.po_item_id)}
                            value={it.unit_price}
                            onChange={(e) => handleItemChange(idx, "unit_price", e.target.value)}
                            className={`w-full px-2.5 py-1.5 border rounded-xl text-xs font-mono font-bold text-emerald-800 ${
                              it.po_item_id ? "bg-slate-100 border-slate-200 cursor-not-allowed" : "bg-white border-slate-200 focus:ring-2 focus:ring-emerald-500"
                            }`}
                            required
                          />
                        </div>
                      </div>

                      {/* Row 2: Tracking (Batch #, Production, Expiry, Location, Serials) */}
                      <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 pt-2 border-t border-slate-200/60">
                        {/* Batch Number */}
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="block text-[11px] font-bold text-slate-600">رقم التشغيلة (Batch #) *</label>
                            <button
                              type="button"
                              onClick={() => {
                                const newBat = `BAT-${todayStr.slice(2).replace(/-/g, "")}-${Math.floor(100 + Math.random() * 900)}`;
                                handleItemChange(idx, "batch_number", newBat);
                              }}
                              className="text-[9px] text-emerald-600 hover:text-emerald-800 font-bold"
                            >
                              توليد
                            </button>
                          </div>
                          <input
                            type="text"
                            value={it.batch_number}
                            onChange={(e) => handleItemChange(idx, "batch_number", e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-800"
                            placeholder="BAT-YYYYMMDD"
                            required
                          />
                        </div>

                        {/* Manufacturing Date */}
                        <div>
                          <label className="block text-[11px] font-bold text-slate-600 mb-1">تاريخ الإنتاج</label>
                          <input
                            type="date"
                            max={todayStr}
                            value={it.manufacturing_date}
                            onChange={(e) => handleItemChange(idx, "manufacturing_date", e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-xl text-xs"
                          />
                        </div>

                        {/* Expiry Date */}
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="block text-[11px] font-bold text-slate-600">تاريخ انتهاء الصلاحية</label>
                            {isNearExpiry && (
                              <span className="text-[9px] text-amber-600 font-bold animate-pulse">أقل من 30 يوم</span>
                            )}
                          </div>
                          <input
                            type="date"
                            value={it.expiry_date}
                            onChange={(e) => handleItemChange(idx, "expiry_date", e.target.value)}
                            className={`w-full px-2.5 py-1.5 border rounded-xl text-xs ${
                              isNearExpiry ? "bg-amber-50 border-amber-300 text-amber-900" : "bg-white border-slate-200"
                            }`}
                          />
                        </div>

                        {/* Warehouse Location (Bin / Shelf) */}
                        <div>
                          <label className="block text-[11px] font-bold text-slate-600 mb-1">موقع التخزين (Bin / Location)</label>
                          <select
                            value={it.location_id}
                            onChange={(e) => handleItemChange(idx, "location_id", e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-medium"
                          >
                            <option value="">-- التخزين الرئيسي للمخزن --</option>
                            {warehouseLocations.map(loc => (
                              <option key={loc.id} value={loc.id}>
                                {loc.code} - {loc.name} {loc.zone ? `(Zone ${loc.zone})` : ""}
                              </option>
                            ))}
                          </select>
                        </div>

                        {/* Serial Numbers */}
                        <div>
                          <label className="block text-[11px] font-bold text-slate-600 mb-1">أرقام تسلسلية (Serials)</label>
                          <input
                            type="text"
                            value={it.serial_numbers}
                            onChange={(e) => handleItemChange(idx, "serial_numbers", e.target.value)}
                            placeholder="SN101, SN102 (اختياري)"
                            className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-mono"
                          />
                        </div>
                      </div>

                      {/* Row 3: Landed Cost Calculation per Unit Breakdown */}
                      <div className="pt-2 border-t border-slate-200/50 flex flex-wrap items-center justify-between text-[11px] font-bold text-slate-700 bg-white/60 p-2 rounded-xl">
                        <div className="flex items-center gap-2">
                          <span className="text-emerald-950">تكلفة الوحدة المخزنية المحملة (Landed Unit Cost):</span>
                          <span className="font-mono text-emerald-800 text-xs">
                            {itemLandedCalc.unitLanded.toFixed(2)} ج.م
                          </span>
                          {itemLandedCalc.extraPerUnit > 0 && (
                            <span className="text-[10px] text-emerald-700">
                              (يشمل +{itemLandedCalc.extraPerUnit.toFixed(2)} ج.م مصاريف شحن ومصروفات محملة)
                            </span>
                          )}
                        </div>
                        <div className="text-slate-500 font-mono text-[10px]">
                          الكمية المقبولة المتوقعة: {Math.max(0, rQty - Number(it.rejected_qty || 0))} {selectedIngredient?.unit || "وحدة"}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 3: 3-WAY MATCHING, ATTACHMENTS, QC SETTINGS & SUMMARY */}
          {step === 3 && (
            <div className="space-y-5">
              {/* 3-Way Matching Summary Box */}
              <div className="bg-slate-900 text-white p-5 rounded-2xl space-y-4 shadow-lg border border-slate-800">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-xs text-slate-200 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    المطابقة الثلاثية (Three-Way Matching) وملخص التكاليف
                  </h4>
                  {threeWayMatch.hasPo ? (
                    threeWayMatch.isMatching ? (
                      <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[11px] px-3 py-1 rounded-full font-bold flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5" /> مطابقة تامة مع أمر الشراء 100%
                      </span>
                    ) : (
                      <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[11px] px-3 py-1 rounded-full font-bold flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5" /> يوجد فرق بقيمة {threeWayMatch.diff.toFixed(2)} ج.م عن أمر الشراء
                      </span>
                    )
                  ) : (
                    <span className="bg-blue-500/20 text-blue-300 border border-blue-500/40 text-[11px] px-3 py-1 rounded-full font-bold">
                      استلام مباشر بدون أمر شراء
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 bg-slate-800/90 rounded-xl border border-slate-700">
                    <span className="text-slate-400 block mb-1">عدد الأصناف المستلمة</span>
                    <span className="text-lg font-black font-mono text-emerald-400">{items.length} صنف</span>
                  </div>

                  <div className="p-3 bg-slate-800/90 rounded-xl border border-slate-700">
                    <span className="text-slate-400 block mb-1">إجمالي الوحدات المستلمة</span>
                    <span className="text-lg font-black font-mono text-blue-400">{calculations.totalQty.toLocaleString()}</span>
                  </div>

                  <div className="p-3 bg-slate-800/90 rounded-xl border border-slate-700">
                    <span className="text-slate-400 block mb-1">صافي قيمة البضاعة</span>
                    <span className="text-lg font-black font-mono text-white">{calculations.netAmount.toLocaleString()} ج.م</span>
                  </div>

                  <div className="p-3 bg-emerald-950/90 rounded-xl border border-emerald-600/50">
                    <span className="text-emerald-300 block mb-1">الإجمالي الشامل المحمل (Landed)</span>
                    <span className="text-lg font-black font-mono text-emerald-400">{calculations.totalLandedCost.toLocaleString()} ج.م</span>
                  </div>
                </div>
              </div>

              {/* Attachments Section */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                <h4 className="font-bold text-xs text-slate-800 flex items-center gap-2">
                  <Paperclip className="w-4 h-4 text-slate-600" />
                  المرفقات والمستندات الورقية (فاتورة المورد، بوليصة الشحن، شهادة الفحص)
                </h4>

                {/* Add Attachment Controls */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                  <input
                    type="text"
                    placeholder="اسم الملف (مثال: صورة الفاتورة الورقية)"
                    value={newAttachmentName}
                    onChange={(e) => setNewAttachmentName(e.target.value)}
                    className="px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <input
                    type="text"
                    placeholder="رابط أو مسار المستند URL / File Path"
                    value={newAttachmentUrl}
                    onChange={(e) => setNewAttachmentUrl(e.target.value)}
                    className="px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs sm:col-span-2 outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <div className="flex gap-2">
                    <select
                      value={newAttachmentType}
                      onChange={(e) => setNewAttachmentType(e.target.value)}
                      className="px-2 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-bold flex-1"
                    >
                      <option value="invoice">فاتورة مورد</option>
                      <option value="delivery_note">إذن تسليم</option>
                      <option value="qc_report">تقرير فحص جودة</option>
                      <option value="other">مستند آخر</option>
                    </select>
                    <button
                      type="button"
                      onClick={handleAddAttachment}
                      className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition-all"
                    >
                      إرفاق
                    </button>
                  </div>
                </div>

                {/* Attachment List */}
                {attachments.length > 0 && (
                  <div className="space-y-1.5 pt-1">
                    {attachments.map((att, i) => (
                      <div key={i} className="flex items-center justify-between p-2.5 bg-white border border-slate-200 rounded-xl text-xs">
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-emerald-600" />
                          <span className="font-bold text-slate-800">{att.file_name}</span>
                          <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-medium">
                            {att.doc_type}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveAttachment(i)}
                          className="text-rose-500 hover:text-rose-700 p-1"
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Quality Inspection & Posting Controls */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Option 1: Send to QC Quarantine */}
                <div className={`p-4 rounded-2xl border transition-all ${
                  header.needs_qc ? "bg-amber-50/70 border-amber-300 shadow-sm ring-2 ring-amber-400/20" : "bg-slate-50 border-slate-200"
                }`}>
                  <label className="flex items-start gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={header.needs_qc}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setHeader({
                          ...header,
                          needs_qc: checked,
                          auto_post: checked ? false : header.auto_post
                        });
                      }}
                      className="w-4 h-4 mt-0.5 rounded text-amber-600 focus:ring-amber-500"
                    />
                    <div>
                      <span className="font-black text-xs text-slate-900 block flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
                        يحتاج فحص جودة وحجر صحي قبل الصرف (Send to QC Quarantine)
                      </span>
                      <span className="text-[11px] text-slate-500 block mt-0.5">
                        سيتم حجز الكميات المستلمة في رصيد الحجر الصحي (Quarantine) ولن تتاح للصرف إلا بعد اعتماد فريق الجودة
                      </span>
                    </div>
                  </label>
                </div>

                {/* Option 2: Direct Instant Post */}
                <div className={`p-4 rounded-2xl border transition-all ${
                  header.auto_post ? "bg-emerald-50/80 border-emerald-400 shadow-sm ring-2 ring-emerald-500/20" : "bg-slate-50 border-slate-200"
                }`}>
                  <label className="flex items-start gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={header.auto_post}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setHeader({
                          ...header,
                          auto_post: checked,
                          needs_qc: checked ? false : header.needs_qc
                        });
                      }}
                      className="w-4 h-4 mt-0.5 rounded text-emerald-600 focus:ring-emerald-500"
                    />
                    <div>
                      <span className="font-black text-xs text-slate-900 block flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        اعتماد وفحص فوري وترحيل محاسبي ومخزني مباشر (Instant Post)
                      </span>
                      <span className="text-[11px] text-slate-500 block mt-0.5">
                        اعتبار جميع الأصناف مقبولة وترحيل الأرصدة المخزنية وتوليد القيد المحاسبي فور الحفظ
                      </span>
                    </div>
                  </label>
                </div>
              </div>

              {/* General Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ملاحظات الاستلام والفحص الأولي</label>
                <textarea
                  rows={2}
                  value={header.notes}
                  onChange={(e) => setHeader({ ...header, notes: e.target.value })}
                  placeholder="ملاحظات حول حالة الشاحنة، السائق، درجات الحرارة، أو أي تلفيات ظاهرية..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          )}

          {/* Wizard Footer Actions */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-200">
            <div>
              {step > 1 && (
                <button
                  type="button"
                  onClick={() => setStep((step - 1) as any)}
                  className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all"
                >
                  <ArrowRight className="w-4 h-4" /> السابق
                </button>
              )}
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all"
              >
                إلغاء
              </button>

              {step < 3 ? (
                <button
                  type="button"
                  onClick={() => setStep((step + 1) as any)}
                  className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-[0.98]"
                >
                  التالي <ArrowLeft className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl shadow-lg shadow-emerald-600/20 disabled:opacity-50 transition-all active:scale-[0.98]"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  {submitting ? "جاري الحفظ والتسجيل..." : "حفظ وتسجيل سند الاستلام"}
                </button>
              )}
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
